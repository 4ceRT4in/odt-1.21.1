package xyz.frxzenluke.titanreborn.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.handler.ConfigHandler;
import xyz.frxzenluke.titanreborn.handler.GameState;
import xyz.frxzenluke.titanreborn.manager.TeamManager;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import static com.mojang.brigadier.builder.LiteralArgumentBuilder.literal;
import static com.mojang.brigadier.builder.RequiredArgumentBuilder.argument;

public class TeamCommand {


    private static final SuggestionProvider<class_2168> SUGGEST_PLAYER_NAMES = (context, builder) -> {
        return class_2172.method_9264(context.getSource().method_9211().method_3760().method_14571().stream()
                .map(player -> player.method_7334().getName()), builder);
    };

    private static final ConcurrentHashMap<UUID, List<UUID>> invites = new ConcurrentHashMap<>();

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(class_2170.method_9247("tteam")
                    .then(class_2170.method_9247("invite")
                            .then(class_2170.method_9244("player", StringArgumentType.string()).suggests(SUGGEST_PLAYER_NAMES)
                                    .executes(context -> {
                                        class_3222 inviter = context.getSource().method_9207();
                                        if (!ConfigHandler.getState(OneDayTitan.getConfigPath()).equals(GameState.LOBBY)) {
                                            inviter.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThis game already started!"), false);
                                            return 0;
                                        }
                                        if(OneDayTitan.soloTeams) {
                                            inviter.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cTeams are disabled for this OneDayTitan!"), false);
                                            return 0;
                                        }
                                        String targetName = StringArgumentType.getString(context, "player");
                                        class_3222 invitee = context.getSource().method_9211().method_3760().method_14566(targetName);

                                        if (invitee != null && invitee.method_5667().equals(inviter.method_5667())) {
                                            inviter.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cYou cannot invite yourself!"), false);
                                            return 0;
                                        }

                                        if (invitee == null) {
                                            inviter.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThis player is not online"), false);
                                            return 0;
                                        }

                                        TeamManager teamManager = TeamManager.getInstance();
                                        if (teamManager.isPlayerInAnyTeam(inviter.method_5667())) {
                                            inviter.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cYou are already in a team! Use /tteam leave to leave."), false);
                                            return 0;
                                        }
                                        if (teamManager.isPlayerInAnyTeam(invitee.method_5667())) {
                                            inviter.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§c" + targetName + " is already in a team!"), false);
                                            return 0;
                                        }

                                        List<UUID> currentInviters = invites.computeIfAbsent(invitee.method_5667(), k -> new ArrayList<>());

                                        if (currentInviters.contains(inviter.method_5667())) {
                                            inviter.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cYou have already invited " + targetName), false);
                                            return 0;
                                        }

                                        invitee.method_17356(class_3417.field_14627, class_3419.field_15248, 1.0F, 1.0F);
                                        inviter.method_17356(class_3417.field_14627, class_3419.field_15248, 1.0F, 1.0F);
                                        invites.computeIfAbsent(invitee.method_5667(), k -> new ArrayList<>()).add(inviter.method_5667());
                                        inviter.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§7You've invited §5" + targetName + " §7to team with you!"), false);
                                        invitee.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§7You've been invited by §5" + inviter.method_5477().getString()
                                                + "§7. Use §a/tteam accept " + inviter.method_5477().getString() + " §7or hit him back within the next §530 §7seconds"), false);

                                        CompletableFuture.delayedExecutor(30, TimeUnit.SECONDS).execute(() -> {
                                            invites.computeIfPresent(invitee.method_5667(), (key, value) -> {
                                                value.remove(inviter.method_5667());
                                                if (value.isEmpty()) {
                                                    inviter.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cYour invite to " + targetName + " has expired"), false);
                                                    invitee.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe invite from " + inviter.method_5477().getString() + " has expired"), false);
                                                    return null;
                                                }
                                                return value;
                                            });
                                        });

                                        return 1;
                                    })
                            )
                    )
                    .then(class_2170.method_9247("accept")
                            .then(class_2170.method_9244("inviter", StringArgumentType.string()).suggests(SUGGEST_PLAYER_NAMES)
                                    .executes(context -> {
                                        class_3222 invitee = context.getSource().method_9207();
                                        if (!ConfigHandler.getState(OneDayTitan.getConfigPath()).equals(GameState.LOBBY)) {
                                            invitee.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThis game already started!"), false);
                                            return 0;
                                        }
                                        if(OneDayTitan.soloTeams) {
                                            invitee.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cTeams are disabled for this OneDayTitan!"), false);
                                            return 0;
                                        }
                                        String inviterName = StringArgumentType.getString(context, "inviter");
                                        class_3222 inviter = context.getSource().method_9211().method_3760().method_14566(inviterName);

                                        if (inviter == null || !invites.containsKey(invitee.method_5667()) || !invites.get(invitee.method_5667()).contains(inviter.method_5667())) {
                                            invitee.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cYou haven't got an invite from " + inviterName), false);
                                            return 0;
                                        }

                                        TeamManager teamManager = TeamManager.getInstance();
                                        teamManager.createTeam(inviter.method_5477().getString() + "'s Team", inviter.method_5667(), invitee.method_5667());
                                        invites.get(invitee.method_5667()).remove(inviter.method_5667());
                                        if (invites.get(invitee.method_5667()).isEmpty()) {
                                            invites.remove(invitee.method_5667());
                                        }
                                        invitee.method_17356(class_3417.field_14704, class_3419.field_15248, 1.0F, 1.0F);
                                        inviter.method_17356(class_3417.field_14704, class_3419.field_15248, 1.0F, 1.0F);
                                        inviter.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§a" + invitee.method_5477().getString() + " has joined your team!"), false);
                                        invitee.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§7You have joined §5" + inviter.method_5477().getString() + "§7's §7team!"), false);
                                        return 1;
                                    })
                            )
                    )
                    .then(class_2170.method_9247("leave")
                            .executes(context -> {
                                class_3222 player = context.getSource().method_9207();
                                TeamManager teamManager = TeamManager.getInstance();
                                if (!ConfigHandler.getState(OneDayTitan.getConfigPath()).equals(GameState.LOBBY)) {
                                    player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThis game already started, therefore you cannot leave your current team!"), false);
                                    return 0;
                                }
                                if (teamManager.isPlayerInAnyTeam(player.method_5667())) {
                                    teamManager.removeTeam(teamManager.getTeamByPlayer(player.method_5667()));
                                    player.method_17356(class_3417.field_14704, class_3419.field_15248, 1.0F, 1.0F);
                                    player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cYou have left your team"), false);
                                } else {
                                    player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cYou're not in a team!"), false);
                                }

                                return 1;
                            })
                    )
            );
        });
    }
    public static UUID getInviterForPlayer(UUID inviteeUuid) {
        return invites.getOrDefault(inviteeUuid, Collections.emptyList())
                .stream()
                .findFirst()
                .orElse(null);
    }
}
package xyz.frxzenluke.titanreborn.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import xyz.frxzenluke.titanreborn.OneDayTitan;

public class InvseeCommand {
    private static final SuggestionProvider<class_2168> SUGGEST_PLAYER_NAMES = (context, builder) -> {
        return class_2172.method_9264(
                context.getSource().method_9211().method_3760().method_14571().stream()
                        .map(player -> player.method_7334().getName()),
                builder
        );
    };
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(class_2170.method_9247("invsee")
                    .requires(source -> source.method_9259(2))
                    .then(class_2170.method_9244("player", StringArgumentType.string())
                            .suggests(SUGGEST_PLAYER_NAMES)
                            .executes(InvseeCommand::execute)
                    )
            );
        });
    }
    private static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {
        String targetPlayerName = StringArgumentType.getString(context, "player");
        class_3222 targetPlayer = context.getSource().method_9211()
                .method_3760().method_14566(targetPlayerName);

        if (targetPlayer == null) {
            context.getSource().method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThis player is not online!"), false);
            return 0;
        }

        class_3222 sourcePlayer = context.getSource().method_9207();
        if (sourcePlayer != null) {
            sourcePlayer.method_17355(new class_3908() {
                @Override
                public class_2561 method_5476() {
                    return class_2561.method_30163(targetPlayerName);
                }
                @Override
                public class_1703 createMenu(int syncId,
                                                net.minecraft.class_1661 playerInventory,
                                                net.minecraft.class_1657 player) {
                    return new class_1707(
                            class_3917.field_18666,
                            syncId,
                            playerInventory,
                            targetPlayer.method_31548(),
                            4
                    );
                }
            });
        }

        return 1;
    }
}
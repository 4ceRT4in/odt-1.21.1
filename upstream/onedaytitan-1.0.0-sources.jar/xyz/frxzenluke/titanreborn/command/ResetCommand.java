package xyz.frxzenluke.titanreborn.command;


import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.server.MinecraftServer;
import xyz.frxzenluke.titanreborn.OneDayTitan;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ResetCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(
                    LiteralArgumentBuilder.<class_2168>literal("reset")
                            .requires(source -> source.method_9259(4))
                            .executes(ResetCommand::execute)
                            .then(
                                    LiteralArgumentBuilder.<class_2168>literal("confirm")
                                            .executes(ResetCommand::confirmReset)
                            )
            );
        });
    }

    private static int execute(CommandContext<class_2168> context) {
        context.getSource().method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§cYou need to confirm the reset by typing §e/reset confirm"), false);
        return 1;
    }

    private static int confirmReset(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        MinecraftServer server = source.method_9211();

        deleteFile("config", "players.json");
        deleteFile("config", "teams.json");
        deleteFile("config", "spawn.json");
        deleteFile("config", "config.json");
        deleteWorldFolder();
        source.method_9211().method_3760().method_14571().forEach(player -> {
            player.field_13987.method_14367(class_2561.method_30163(OneDayTitan.getPrefix() + "\n§cServer Reset!"));
        });
        server.method_3782();
        return 1;
    }

    private static void deleteFile(String directory, String fileName) {
        Path configPath = Paths.get(directory, fileName);
        if (Files.exists(configPath)) {
            try {
                Files.delete(configPath);
            } catch (IOException e) {
                System.err.println("Failed to delete config file: " + fileName);
            }
        }
    }

    private static void deleteWorldFolder() {
        Path worldPath = Paths.get("world");
        if (Files.exists(worldPath)) {
            try {
                Files.walk(worldPath)
                        .sorted((path1, path2) -> path2.compareTo(path1))
                        .forEach(path -> {
                            try {
                                Files.delete(path);
                            } catch (IOException e) {
                                System.err.println("Failed to delete file: " + path);
                            }
                        });
            } catch (IOException e) {
                System.err.println("Failed to delete world folder.");
            }
        }
    }
}
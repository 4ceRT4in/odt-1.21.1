package xyz.frxzenluke.titanreborn.command;

import com.google.gson.Gson;
import com.mojang.brigadier.Command;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_1267;
import net.minecraft.class_1928;
import net.minecraft.class_1934;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_26;
import net.minecraft.class_2784;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.handler.ConfigHandler;
import xyz.frxzenluke.titanreborn.handler.GameState;
import xyz.frxzenluke.titanreborn.manager.PlayerManager;
import xyz.frxzenluke.titanreborn.manager.StartStuffManager;
import xyz.frxzenluke.titanreborn.manager.TeamManager;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class StartCommand {
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    public static final ScheduledExecutorService protectionTimeScheduler = Executors.newScheduledThreadPool(1);
    private static final ScheduledExecutorService borderScheduler = Executors.newScheduledThreadPool(1);

    private static boolean startedCountdown = false;
    public static boolean protectionTime = false;


    public static void register(Path configPath) {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(class_2170.method_9247("start")
                    .requires(source -> source.method_9259(2))
                    .executes(context -> startCountdown(context.getSource(), configPath))
            );
        });
    }

    private static void startProtectionTime(class_2168 source) {
        protectionTime = true;
        source.method_9211().method_3760().method_14571().forEach(player -> {
            player.method_17356(class_3417.field_14624,
                    class_3419.field_15248,
                    1.0F,
                    1.0F
            );
            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period lasts §b20 §cminutes!"), false);
        });

        protectionTimeScheduler.scheduleAtFixedRate(new Runnable() {
            int countdown = 1200;
            @Override
            public void run() {
                if (countdown <= 0) {
                    protectionTime = false;
                    source.method_9211().method_3760().method_14571().forEach(player -> {
                        player.method_17356(class_3417.field_14671,
                                class_3419.field_15248,
                                1.0F,
                                1.0F
                        );
                        player.method_7353(class_2561.method_30163("§8✕ §7Grace Period ends in: §5NOW"), true);
                        player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period is now over!"), false);
                    });
                    protectionTimeScheduler.shutdown();
                } else {
                    if(countdown == 900 || countdown == 600 || countdown == 300 || countdown == 240 || countdown == 180|| countdown == 120) {
                        source.method_9211().method_3760().method_14571().forEach(player -> {
                            player.method_17356(class_3417.field_14624,
                                    class_3419.field_15248,
                                    1.0F,
                                    1.0F
                            );
                            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period ends in §b" + (countdown / 60) + " §cminutes!"), false);
                        });
                    } else if (countdown == 60) {
                        source.method_9211().method_3760().method_14571().forEach(player -> {
                            player.method_17356(class_3417.field_14624,
                                    class_3419.field_15248,
                                    1.0F,
                                    1.0F
                            );
                            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period ends in §b" + (countdown / 60) + " §cminute!"), false);
                        });
                    } else if (countdown == 30 || countdown == 15 || countdown == 10 || countdown == 5 || countdown == 4 || countdown == 3 || countdown == 2) {
                        source.method_9211().method_3760().method_14571().forEach(player -> {
                            player.method_17356(class_3417.field_14624,
                                    class_3419.field_15248,
                                    1.0F,
                                    1.0F
                            );
                            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period ends in §b" + countdown + " §cseconds!"), false);
                        });
                    } else if (countdown == 1) {
                        source.method_9211().method_3760().method_14571().forEach(player -> {
                            player.method_17356(class_3417.field_14624,
                                    class_3419.field_15248,
                                    1.0F,
                                    1.0F
                            );
                            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period ends in §b" + countdown + " §csecond!"), false);
                        });
                    }
                    source.method_9211().method_3760().method_14571().forEach(player -> {
                        if(countdown > 60) {
                            player.method_7353(class_2561.method_30163("§8✕ §7Grace Period ends in: §5" + (int) (countdown / 60)  + " §7minutes"), true);
                        } else {
                            player.method_7353(class_2561.method_30163("§8✕ §7Grace Period ends in: §5" + countdown + " §7seconds"), true);
                        }
                    });
                    countdown--;
                }
            }
        }, 0, 1, TimeUnit.SECONDS);
    }

    private static int startCountdown(class_2168 source, Path configPath) {
        if(ConfigHandler.getState(configPath) == GameState.LOBBY && !startedCountdown) {
            startedCountdown = true;
            scheduler.scheduleAtFixedRate(new Runnable() {
                int countdown = 30;

                @Override
                public void run() {
                    if (countdown <= 0) {
                        for (class_3218 world : source.method_9211().method_3738()) {
                            if(world != null) {
                                world.method_29199(1000);
                                world.method_8450().method_20746(class_1928.field_19409).method_20758(false, world.method_8503());
                                world.method_8450().method_20746(class_1928.field_19396).method_20758(true, world.method_8503());
                                world.method_8450().method_20746(class_1928.field_19390).method_20758(true, world.method_8503());
                                world.method_8450().method_20746(class_1928.field_19406).method_20758(false, world.method_8503());
                                class_2784 worldBorder = world.method_8621();
                                worldBorder.method_11969(1500);
                            }
                        }
                        source.method_9211().method_3776(class_1267.field_5802, true);
                        source.method_9211().method_3760().method_14571().forEach(player -> {
                            player.method_17356(class_3417.field_14671,
                                    class_3419.field_15248,
                                    1.0F,
                                    1.0F
                            );
                            player.method_31548().method_5448();
                            player.method_14228(0);
                            player.method_14252(0);
                            player.method_6033(20);
                            player.method_7346();
                            PlayerManager.getInstance().addPlayer(player.method_5667(), player.method_5477().method_10851());
                            player.method_7344().method_7581(5);
                            player.method_7336(class_1934.field_9215);
                            if(!TeamManager.getInstance().isPlayerInAnyTeam(player.method_5667())) {
                                TeamManager.getInstance().createTeam(player.method_5477().method_10851(), player.method_5667(), null);
                            }
                            StartStuffManager.loadStartStuff(player);
                            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§bThis OneDayTitan starts §3now§b!"), false);
                            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe WorldBorder has a Radius of §b" + source.method_9225().method_8621().method_11965() + " §cBlocks."), false);
                        });
                        clearSaveInv(source.method_9211());
                        ConfigHandler.setState(configPath, GameState.STARTED);
                        startProtectionTime(source);
                        scheduler.shutdown();
                    } else {
                        if (countdown == 30 || countdown == 15 || countdown == 10 || countdown == 5 || countdown == 4 || countdown == 3 || countdown == 2) {
                            source.method_9211().method_3760().method_14571().forEach(player -> {
                                player.method_17356(class_3417.field_14627,
                                        class_3419.field_15248,
                                        1.0F,
                                        1.0F
                                );
                                player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§bThis OneDayTitan starts in §3" + countdown + " §bseconds!"), false);
                            });
                        } else if (countdown == 1) {
                            source.method_9211().method_3760().method_14571().forEach(player -> {
                                player.method_17356(class_3417.field_14627,
                                        class_3419.field_15248,
                                        1.0F,
                                        1.0F
                                );
                                player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§bThis OneDayTitan starts in §3" + countdown + " §bsecond!"), false);
                            });
                        }
                        source.method_9211().method_3760().method_14571().forEach(player -> {
                            player.method_14252(countdown);
                            player.method_14228(0);
                        });
                        countdown--;
                    }
                }
            }, 0, 1, TimeUnit.SECONDS);
        } else {
            source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThis OneDayTitan has already began."), false);
        }
        return 1;
    }
    public static void clearSaveInv(MinecraftServer server) {
        if (server == null) {
            return;
        }
        for (class_3218 world : server.method_3738()) {
            try {
                class_26 stateManager = world.method_17983();
                stateManager.method_123("titanfabric", null);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }
}

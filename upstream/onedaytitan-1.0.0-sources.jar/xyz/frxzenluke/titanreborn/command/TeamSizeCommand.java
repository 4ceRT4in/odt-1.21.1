package xyz.frxzenluke.titanreborn.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.handler.ConfigHandler;
import xyz.frxzenluke.titanreborn.handler.GameState;
import xyz.frxzenluke.titanreborn.manager.TeamManager;

public class TeamSizeCommand {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(
                    LiteralArgumentBuilder.<class_2168>literal("teamsize").requires(source -> source.method_9259(2))
                            .then(
                                    LiteralArgumentBuilder.<class_2168>literal("solos")
                                            .executes(TeamSizeCommand::solos)
                            ).then(
                                    LiteralArgumentBuilder.<class_2168>literal("duos")
                                            .executes(TeamSizeCommand::duos)
                            )
            );
        });
    }
    private static int solos(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (ConfigHandler.getState(OneDayTitan.getConfigPath()) == GameState.STARTED) {
            source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThis game already started!"), false);
            return 0;
        }
        if(OneDayTitan.soloTeams) {
            source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe team size is already solos!"), false);
            return 0;
        }
        MinecraftServer server = context.getSource().method_9211();
        OneDayTitan.soloTeams = true;
        TeamManager.getInstance().removeAllTeams();
        server.method_3760().method_14571().forEach(playerAll -> {
            playerAll.method_17356(class_3417.field_14627,
                    class_3419.field_15248,
                    1.0F,
                    1.0F
            );
            playerAll.method_31548().method_5448();
            playerAll.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§bThe team size was changed to §3Solo§b!"), false);
        });
        return 1;
    }
    private static int duos(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (ConfigHandler.getState(OneDayTitan.getConfigPath()) == GameState.STARTED) {
            source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThis game already started!"), false);
            return 0;
        }
        if(!OneDayTitan.soloTeams) {
            source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe team size is already duos!"), false);
            return 0;
        }
        OneDayTitan.soloTeams = false;
        MinecraftServer server = context.getSource().method_9211();
        class_1792 legendSwordItem = class_2378.field_11142.method_10223(new class_2960("titanfabric", "legend_sword"));
        class_1799 item = new class_1799(legendSwordItem);
        item.method_7977(new class_2585("§8» §5Invite"));
        server.method_3760().method_14571().forEach(playerAll -> {
            playerAll.method_17356(class_3417.field_14627,
                    class_3419.field_15248,
                    1.0F,
                    1.0F
            );
            playerAll.method_31548().method_5447(0, item);
            playerAll.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§bThe team size was changed to §3Duos§b!"), false);
        });
        return 1;
    }
}

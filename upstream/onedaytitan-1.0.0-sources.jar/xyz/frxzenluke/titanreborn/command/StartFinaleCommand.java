package xyz.frxzenluke.titanreborn.command;

import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2784;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.event.PlayerJoinEvent;
import xyz.frxzenluke.titanreborn.handler.ConfigHandler;
import xyz.frxzenluke.titanreborn.handler.GameState;
import xyz.frxzenluke.titanreborn.manager.PlayerManager;
import xyz.frxzenluke.titanreborn.manager.StartStuffManager;
import xyz.frxzenluke.titanreborn.manager.TeamManager;

import java.nio.file.Path;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class StartFinaleCommand {
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    public static final ScheduledExecutorService protectionTimeScheduler = Executors.newScheduledThreadPool(1);

    public static boolean isFinaleStarted = false;

    public static void register(Path configPath) {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(class_2170.method_9247("startfinale")
                    .requires(source -> source.method_9259(2))
                    .executes(context -> startCountdown(context.getSource(), configPath))
            );
        });
    }

    private static void startProtectionTime(class_2168 source) {
        source.method_9211().method_3760().method_14571().forEach(player -> {
            player.method_17356(class_3417.field_14624,
                    class_3419.field_15248,
                    1.0F,
                    1.0F
            );
            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period lasts §b1 §cminute!"), false);
        });

        protectionTimeScheduler.scheduleAtFixedRate(new Runnable() {
            int countdown = 60;
            @Override
            public void run() {
                if (countdown <= 0) {
                    StartCommand.protectionTime = false;
                    source.method_9211().method_3760().method_14571().forEach(player -> {
                        player.method_17356(class_3417.field_14671,
                                class_3419.field_15248,
                                1.0F,
                                1.0F
                        );
                        player.method_7353(class_2561.method_30163("§8✕ §7Grace Period ends in: §5NOW"), true);
                        player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period is now over!"), false);
                    });
                    protectionTimeScheduler.shutdown();
                } else {
                    if (countdown == 30 || countdown == 15 || countdown == 10 || countdown == 5 || countdown == 4 || countdown == 3 || countdown == 2) {
                        source.method_9211().method_3760().method_14571().forEach(player -> {
                            player.method_17356(class_3417.field_14624,
                                    class_3419.field_15248,
                                    1.0F,
                                    1.0F
                            );
                            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period ends in §b" + countdown + " §cseconds!"), false);
                        });
                    } else if (countdown == 1) {
                        source.method_9211().method_3760().method_14571().forEach(player -> {
                            player.method_17356(class_3417.field_14624,
                                    class_3419.field_15248,
                                    1.0F,
                                    1.0F
                            );
                            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period ends in §b" + countdown + " §csecond!"), false);
                        });
                    }
                    source.method_9211().method_3760().method_14571().forEach(player -> {
                        player.method_7353(class_2561.method_30163("§8✕ §7Grace Period ends in: §5" + countdown + " §7seconds"), true);
                    });
                    countdown--;
                }
            }
        }, 0, 1, TimeUnit.SECONDS);
    }

    private static int startCountdown(class_2168 source, Path configPath) {
        if(ConfigHandler.getState(configPath) == GameState.STARTED) {
            if(isFinaleStarted) {
                source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe Finale was already started!"), false);
                return 0;
            }
            isFinaleStarted = true;
            scheduler.scheduleAtFixedRate(new Runnable() {
                int countdown = 30;

                @Override
                public void run() {
                    if (countdown <= 0) {
                        for (class_3218 world : source.method_9211().method_3738()) {
                            if(world != null) {
                                class_2784 worldBorder = world.method_8621();
                                worldBorder.method_11969(200);
                            }
                        }
                        StartCommand.protectionTime = true;
                        class_2338 spawnPos = PlayerJoinEvent.readSpawnCoordinates();
                        source.method_9211().method_3760().method_14571().forEach(player -> {
                            player.method_17356(class_3417.field_14671,
                                    class_3419.field_15248,
                                    1.0F,
                                    1.0F
                            );
                            if (spawnPos != null) {
                                class_3218 world = source.method_9211().method_30002();
                                player.method_14251(world, spawnPos.method_10263(), spawnPos.method_10264() + 10, spawnPos.method_10260(), 0, 0);
                            }
                            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§bThe Finale starts §3now§b!"), false);
                            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe WorldBorder has a Radius of §b" + source.method_9225().method_8621().method_11965() + " §cBlocks."), false);
                        });
                        startProtectionTime(source);
                        scheduler.shutdown();
                    } else {
                        if (countdown == 30 || countdown == 15 || countdown == 10 || countdown == 5 || countdown == 4 || countdown == 3 || countdown == 2) {
                            source.method_9211().method_3760().method_14571().forEach(player -> {
                                player.method_17356(class_3417.field_14627,
                                        class_3419.field_15248,
                                        1.0F,
                                        1.0F
                                );
                                player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§bThe Finale starts in §3" + countdown + " §bseconds!"), false);
                            });
                        } else if (countdown == 1) {
                            source.method_9211().method_3760().method_14571().forEach(player -> {
                                player.method_17356(class_3417.field_14627,
                                        class_3419.field_15248,
                                        1.0F,
                                        1.0F
                                );
                                player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§bThe Finale starts in §3" + countdown + " §bsecond!"), false);
                            });
                        }
                        countdown--;
                    }
                }
            }, 0, 1, TimeUnit.SECONDS);
        } else {
            source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe game must be started in order for the finale to happen!"), false);
        }
        return 1;
    }
}

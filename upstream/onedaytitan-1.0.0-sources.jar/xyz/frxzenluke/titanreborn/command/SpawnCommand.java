package xyz.frxzenluke.titanreborn.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import xyz.frxzenluke.titanreborn.OneDayTitan;

import static xyz.frxzenluke.titanreborn.event.PlayerJoinEvent.readSpawnCoordinates;

public class SpawnCommand {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(
                    LiteralArgumentBuilder.<class_2168>literal("spawn")
                            .executes(SpawnCommand::execute)
            );
        });
    }
    private static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        class_2338 spawnPos = readSpawnCoordinates();
        if (spawnPos != null) {
            source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§7The Spawn is located at §5" + spawnPos.method_10263() + "§7, §5" + spawnPos.method_10264() + "§7, §5" + spawnPos.method_10260()), false);
        } else {
            source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe Spawn Location hasn't been set!"), false);
        }
        return 1;
    }
}

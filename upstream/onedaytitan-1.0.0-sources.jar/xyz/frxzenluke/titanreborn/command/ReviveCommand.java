package xyz.frxzenluke.titanreborn.command;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_1934;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.core.jmx.Server;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.event.PlayerJoinEvent;
import xyz.frxzenluke.titanreborn.manager.PlayerManager;
import xyz.frxzenluke.titanreborn.manager.StartStuffManager;
import xyz.frxzenluke.titanreborn.manager.TeamManager;
import xyz.frxzenluke.titanreborn.manager.states.PlayerState;
import xyz.frxzenluke.titanreborn.manager.states.TeamState;

import java.util.UUID;


public class ReviveCommand {
    private static final SuggestionProvider<class_2168> SUGGEST_PLAYER_NAMES = (context, builder) -> {
        return class_2172.method_9264(
                context.getSource().method_9211().method_3760().method_14571().stream()
                        .map(player -> player.method_7334().getName()),
                builder
        );
    };

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(class_2170.method_9247("revive")
                    .requires(source -> source.method_9259(2))
                    .then(class_2170.method_9244("player", StringArgumentType.string())
                            .suggests(SUGGEST_PLAYER_NAMES)
                            .executes(ReviveCommand::execute)
                    )
            );
        });
    }

    private static int execute(CommandContext<class_2168> context) {
        String playerName = StringArgumentType.getString(context, "player");
        class_2168 source = context.getSource();
        PlayerManager playerManager = PlayerManager.getInstance();
        UUID playerUUID = playerManager.getUUIDByName(playerName);
        if (playerUUID == null) {
            source.method_9213(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThis player couldn't be found"));
            return 0;
        }

        if (playerManager.getPlayerState(playerUUID) == PlayerState.ALIVE) {
            source.method_9213(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThis player is still alive"));
            return 0;
        }
        playerManager.setPlayerState(playerUUID, PlayerState.ALIVE);
        source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§7The player §5" + playerName + " §7was revived"), false);
        class_3222 targetPlayer = source.method_9211().method_3760().method_14602(playerUUID);
        if(targetPlayer != null) {
            class_2338 spawnPos = PlayerJoinEvent.readSpawnCoordinates();
            if (spawnPos != null) {
                class_3218 world = source.method_9211().method_30002();
                targetPlayer.method_14251(world, spawnPos.method_10263(), spawnPos.method_10264(), spawnPos.method_10260(), 0, 0);
            }
            targetPlayer.method_7336(class_1934.field_9215);
            targetPlayer.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§bYou were §5revived§b!"), false);
            targetPlayer.method_17356(class_3417.field_14627, class_3419.field_15248, 1.0F, 1.0F);
        }
        String teamKey = getTeamKeyByPlayer(playerUUID, TeamManager.getInstance());
        if (teamKey != null) {
            TeamState teamState = TeamManager.getInstance().getTeamState(teamKey);
            if (teamState == TeamState.DEAD) {
                TeamManager.getInstance().setTeamState(teamKey, TeamState.ALIVE);
            }
        }
        return 1;
    }

    private static String getTeamKeyByPlayer(UUID playerUUID, TeamManager teamManager) {
        for (String teamKey : teamManager.getAllTeams()) {
            if (teamManager.getPlayersInTeam(teamKey).contains(playerUUID.toString())) {
                return teamKey;
            }
        }
        return null;
    }
}
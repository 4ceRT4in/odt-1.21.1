package xyz.frxzenluke.titanreborn.command;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2784;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.manager.StartStuffManager;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class SetSpawnCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(
                    LiteralArgumentBuilder.<class_2168>literal("setspawn").requires(source -> source.method_9259(2))
                            .executes(SetSpawnCommand::execute)
            );
        });
    }
    private static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (source.method_9228() instanceof class_3222 player) {
            class_243 pos = player.method_19538();
            class_2338 spawnPos = new class_2338(pos);
            File configDir = new File("config");
            if (!configDir.exists()) {
                configDir.mkdirs();
            }
            File spawnFile = new File(configDir, "spawn.json");
            JsonObject spawnData = new JsonObject();
            spawnData.addProperty("x", spawnPos.method_10263());
            spawnData.addProperty("y", spawnPos.method_10264());
            spawnData.addProperty("z", spawnPos.method_10260());
            try (FileWriter writer = new FileWriter(spawnFile)) {
                Gson gson = new Gson();
                gson.toJson(spawnData, writer);
            } catch (IOException e) {
                e.printStackTrace();
                source.method_9226(class_2561.method_30163("§cFailed to save spawn coordinates."), false);
                return 1;
            }
            player.method_17356(class_3417.field_14627,
                    class_3419.field_15248,
                    1.0F,
                    1.0F
            );
            MinecraftServer server = source.method_9211();
            server.method_3738().forEach(world -> {
                class_2784 worldBorder = world.method_8621();
                worldBorder.method_11978(spawnPos.method_10263(), spawnPos.method_10260());
                worldBorder.method_11969(50);
                world.method_8554(spawnPos, 0);
            });
            source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§aThe spawn has successfully been set to your current location."), false);
        }

        return 1;
    }
}

package xyz.frxzenluke.titanreborn.command;

import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import xyz.frxzenluke.titanreborn.manager.PlayerManager;
import xyz.frxzenluke.titanreborn.manager.TeamManager;

import java.nio.file.Path;

public class ReloadCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(class_2170.method_9247("reloadconfig")
                    .requires(source -> source.method_9259(2))
                    .executes(context -> reload(context.getSource()))
            );
        });
    }
    private static int reload(class_2168 source) {
        source.method_9226(class_2561.method_30163("§eReloading Files..."), false);
        TeamManager.getInstance().loadTeams();
        PlayerManager.getInstance().loadAlivePlayers();
        source.method_9226(class_2561.method_30163("§aReload done."), false);
        return 1;
    }
}

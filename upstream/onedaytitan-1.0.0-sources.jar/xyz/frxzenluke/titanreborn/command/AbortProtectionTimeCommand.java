package xyz.frxzenluke.titanreborn.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import xyz.frxzenluke.titanreborn.OneDayTitan;

public class AbortProtectionTimeCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(
                    LiteralArgumentBuilder.<class_2168>literal("abortprotectiontime").requires(source -> source.method_9259(2))
                            .executes(AbortProtectionTimeCommand::execute)
            );
        });
    }
    private static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if(StartCommand.protectionTime) {
            StartCommand.protectionTime = false;
            StartCommand.protectionTimeScheduler.shutdown();
            source.method_9211().method_3760().method_14571().forEach(player -> {
                player.method_17356(class_3417.field_14671,
                        class_3419.field_15248,
                        1.0F,
                        1.0F
                );
                player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period is now over!"), false);
                player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe grace period was forcefully ended by a Staff Member."), false);
            });
        }
        return 1;
    }
}

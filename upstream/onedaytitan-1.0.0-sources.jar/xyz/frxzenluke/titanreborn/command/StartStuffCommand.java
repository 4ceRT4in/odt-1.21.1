package xyz.frxzenluke.titanreborn.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_3222;
import xyz.frxzenluke.titanreborn.manager.StartStuffManager;

public class StartStuffCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(
                    LiteralArgumentBuilder.<class_2168>literal("setstartstuff").requires(source -> source.method_9259(2))
                            .executes(StartStuffCommand::execute)
            );
        });
    }

    private static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (source.method_9228() instanceof class_3222 player) {
            StartStuffManager.saveStartStuff(player);
        }
        return 1;
    }
}
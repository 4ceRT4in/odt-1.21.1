package xyz.frxzenluke.titanreborn.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.manager.StartStuffManager;

import java.nio.file.Path;

public class BorderCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(
                    LiteralArgumentBuilder.<class_2168>literal("border")
                            .executes(BorderCommand::execute)
            );
        });
    }
    private static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        source.method_9226(class_2561.method_30163(OneDayTitan.getPrefix() + "§7The current radius of the WorldBorder §7is §5" + source.method_9225().method_8621().method_11965() + " §7blocks"), false);
        return 1;
    }
}

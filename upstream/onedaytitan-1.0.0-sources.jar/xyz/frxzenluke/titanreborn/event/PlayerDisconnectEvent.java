package xyz.frxzenluke.titanreborn.event;

import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_2561;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.handler.ConfigHandler;
import xyz.frxzenluke.titanreborn.manager.PlayerManager;
import xyz.frxzenluke.titanreborn.manager.TeamManager;
import xyz.frxzenluke.titanreborn.manager.states.PlayerState;

import java.util.*;
import java.util.concurrent.*;

public class PlayerDisconnectEvent implements ServerPlayConnectionEvents.Disconnect{
    static final ConcurrentHashMap<UUID, Timer> disconnectTimers = new ConcurrentHashMap<>();


    @Override
    public void onPlayDisconnect(class_3244 handler, MinecraftServer server) {
        switch (ConfigHandler.getState(OneDayTitan.getConfigPath())) {
            case LOBBY -> {
                if (TeamManager.getInstance().isPlayerInAnyTeam(handler.field_14140.method_5667())) {
                    TeamManager.getInstance().removeTeam(TeamManager.getInstance().getTeamNameById(TeamManager.getInstance().getNextTeamId() - 1));
                }
                server.method_3760().method_14571().forEach(player -> {
                    player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§5" + handler.field_14140.method_5477().method_10851() + " §bhas left the game."), false);
                });
            }
            case STARTED -> {
                if (PlayerManager.getInstance().isPlayerAdded(handler.field_14140.method_5667()) && PlayerManager.getInstance().getPlayerState(handler.field_14140.method_5667()) == PlayerState.ALIVE) {
                    Timer timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            PlayerManager.getInstance().setPlayerState(handler.field_14140.method_5667(), PlayerState.DEAD);
                            server.method_3760().method_14571().forEach(player -> {
                                player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§5" + handler.field_14140.method_5477().method_10851() + " §chasn't reconnected for 5 minutes, therefore he is now removed from this OneDayTitan!"), false);
                            });
                            disconnectTimers.remove(handler.field_14140.method_5667());
                        }
                    }, 5 * 60 * 1000);
                    disconnectTimers.put(handler.field_14140.method_5667(), timer);
                    server.method_3760().method_14571().forEach(player -> {
                        player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§5" + handler.field_14140.method_5477().method_10851() + " §bhas left the game. He has §55 §bminutes to reconnect!"), false);
                    });
                }
            }
        }
    }
}

package xyz.frxzenluke.titanreborn.event;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_268;
import net.minecraft.class_2960;
import net.minecraft.class_2995;
import net.minecraft.class_3218;
import net.minecraft.class_3244;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.handler.ConfigHandler;
import xyz.frxzenluke.titanreborn.manager.PlayerManager;
import xyz.frxzenluke.titanreborn.manager.StartStuffManager;
import xyz.frxzenluke.titanreborn.manager.states.PlayerState;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.UUID;

public class PlayerJoinEvent implements ServerPlayConnectionEvents.Join {

    @Override
    public void onPlayReady(class_3244 handler, PacketSender sender, MinecraftServer server) {
        switch (ConfigHandler.getState(OneDayTitan.getConfigPath())) {
            case LOBBY -> {
                removePlayerFromAllTeams(handler.field_14140, server);
                handler.field_14140.method_7336(class_1934.field_9216);
                handler.field_14140.method_31548().method_5448();
                handler.field_14140.method_6033(20);
                handler.field_14140.method_7344().method_7581(10000);
                handler.field_14140.method_7344().method_7580(20);
                handler.field_14140.method_6033(20);
                handler.field_14140.method_14252(0);
                handler.field_14140.method_14228(0);
                handler.field_14140.method_17356(class_3417.field_14627,
                        class_3419.field_15248,
                        1.0F,
                        1.0F
                );
                if(!OneDayTitan.soloTeams) {
                    class_1792 legendSwordItem = class_2378.field_11142.method_10223(new class_2960("titanfabric", "legend_sword"));
                    class_1799 item = new class_1799(legendSwordItem);
                    item.method_7977(new class_2585("§8» §5Invite"));
                    handler.field_14140.method_31548().method_5447(0, item);
                }
                class_2338 spawnPos = readSpawnCoordinates();
                if (spawnPos != null) {
                    class_3218 world = server.method_30002();
                    handler.field_14140.method_14251(world, spawnPos.method_10263(), spawnPos.method_10264(), spawnPos.method_10260(), 0, 0);
                }
                server.method_3760().method_14571().forEach(player -> {
                    player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§5" + handler.method_32311().method_5477().method_10851() + " §bhas joined the game."), false);
                });
            }
            case STARTED -> {
                if(!PlayerManager.getInstance().isPlayerAdded(handler.field_14140.method_5667()) || PlayerManager.getInstance().getPlayerState(handler.field_14140.method_5667()) != PlayerState.ALIVE) {
                    handler.field_14140.method_17356(class_3417.field_14624,
                            class_3419.field_15248,
                            1.0F,
                            1.0F
                    );
                    handler.field_14140.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cYou joined a running game, therefore you are now a spectator..."), false);
                    handler.field_14140.method_7336(class_1934.field_9219);
                } else if (PlayerManager.getInstance().isPlayerAdded(handler.field_14140.method_5667()) && PlayerManager.getInstance().getPlayerState(handler.field_14140.method_5667()) == PlayerState.ALIVE) {
                    handler.field_14140.method_17356(class_3417.field_14627,
                            class_3419.field_15248,
                            1.0F,
                            1.0F
                    );
                    if (PlayerDisconnectEvent.disconnectTimers.containsKey(handler.field_14140.method_5667())) {
                        PlayerDisconnectEvent.disconnectTimers.get(handler.field_14140.method_5667()).cancel();
                        PlayerDisconnectEvent.disconnectTimers.remove(handler.field_14140.method_5667());
                    }
                    server.method_3760().method_14571().forEach(player -> {
                        player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§5" + handler.field_14140.method_5477().method_10851() + " §bhas reconnected."), false);
                    });
                }
            }
        }
    }

    public static class_2338 readSpawnCoordinates() {
        File configDir = new File("config");
        File spawnFile = new File(configDir, "spawn.json");

        if (spawnFile.exists()) {
            try (FileReader reader = new FileReader(spawnFile)) {
                JsonObject spawnData = new Gson().fromJson(reader, JsonObject.class);
                int x = spawnData.get("x").getAsInt();
                int y = spawnData.get("y").getAsInt();
                int z = spawnData.get("z").getAsInt();
                return new class_2338(x, y, z);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private static void removePlayerFromAllTeams(class_1657 player, MinecraftServer server) {
        class_2995 scoreboard = server.method_3845();
        for (class_268 team : scoreboard.method_1159()) {
            if (team.method_1204().contains(player.method_5820())) {
                scoreboard.method_1157(player.method_5820(), team);
            }
        }
    }
}

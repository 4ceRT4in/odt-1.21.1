package xyz.frxzenluke.titanreborn.mixin;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1281;
import net.minecraft.class_1282;
import net.minecraft.class_1283;
import net.minecraft.class_1295;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_1676;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2784;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.command.StartCommand;
import xyz.frxzenluke.titanreborn.command.TeamCommand;
import xyz.frxzenluke.titanreborn.handler.ConfigHandler;
import xyz.frxzenluke.titanreborn.handler.GameState;
import xyz.frxzenluke.titanreborn.manager.PlayerManager;
import xyz.frxzenluke.titanreborn.manager.TeamManager;
import xyz.frxzenluke.titanreborn.manager.states.PlayerState;
import xyz.frxzenluke.titanreborn.manager.states.TeamState;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

@Mixin(class_3222.class)
public abstract class ServerPlayerEntityMixin {

    @Inject(at = @At("HEAD"), method = "onDeath(Lnet/minecraft/entity/damage/DamageSource;)V")
    public void onDeath(class_1282 source, CallbackInfo ci) {
        class_3222 player = (class_3222) (Object) this;
        MinecraftServer server = player.method_5682();
        if (ConfigHandler.getState(OneDayTitan.getConfigPath()) == GameState.STARTED) {
            server.method_3760().method_14571().forEach(playerAll -> {
                playerAll.method_17356(class_3417.field_14624, class_3419.field_15248, 1.0F, 1.0F);
                playerAll.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cThe WorldBorder is shrinking to §b"+ (int) (playerAll.method_14220().method_8621().method_11965() - 25) + " §cblocks over the next §b60 §cseconds!"), false);
            });
            for (class_3218 world : server.method_3738()) {
                class_2784 worldBorder = world.method_8621();
                worldBorder.method_11957(worldBorder.method_11965(), (worldBorder.method_11965() - 50), 60 * 1000);
            }
            class_3222 killer = getKillerFromDamageSource(source);
            if (killer == null) {
                killer = getKillerFromDamageTracker(player);
            }
            if (killer != null) {
                class_3222 finalKiller = killer;
                server.method_3760().method_14571().forEach(playerAll -> {
                    playerAll.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§5" + finalKiller.method_5477().method_10851() + " §bhas killed §5" + player.method_5477().method_10851() + "§b."), false);
                });
                finalKiller.method_7353(class_2561.method_30163("§8✕ §b§l+3 Level"), true);
                finalKiller.method_7316(3);
            } else {
                server.method_3760().method_14571().forEach(playerAll -> {
                    playerAll.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§5" + player.method_5477().method_10851() + " §bdied."), false);
                });
            }
            new Thread(() -> {
                try {
                    Thread.sleep(1000);
                    player.method_7336(class_1934.field_9219);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
            PlayerManager.getInstance().setPlayerState(player.method_5667(), PlayerState.DEAD);
            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cYou're now a spectator!"), false);
            TeamManager teamManager = TeamManager.getInstance();
            String teamKey = getTeamKeyByPlayer(player.method_5667(), teamManager);
            if (teamKey != null) {
                List<String> playersInTeam = teamManager.getPlayersInTeam(teamKey);
                boolean allDead = playersInTeam.stream()
                        .map(UUID::fromString)
                        .allMatch(uuid -> PlayerManager.getInstance().getPlayerState(uuid) == PlayerState.DEAD);
                if (allDead) {
                    teamManager.setTeamState(teamKey, TeamState.DEAD);
                    checkForWinningTeam(teamManager);
                }
            }
        }
    }
    @Unique
    private String getTeamKeyByPlayer(UUID playerUUID, TeamManager teamManager) {
        for (String teamKey : teamManager.getAllTeams()) {
            List<String> playersInTeam = teamManager.getPlayersInTeam(teamKey);
            if (playersInTeam.contains(playerUUID.toString())) {
                return teamKey;
            }
        }
        return null;
    }

    @Unique
    private void checkForWinningTeam(TeamManager teamManager) {
        Set<String> allTeams = teamManager.getAllTeams();
        long aliveTeamsCount = allTeams.stream()
                .filter(teamKey -> teamManager.getTeamState(teamKey) == TeamState.ALIVE)
                .count();
        if (aliveTeamsCount == 1) {
            String winningTeamKey = allTeams.stream()
                    .filter(teamKey -> teamManager.getTeamState(teamKey) == TeamState.ALIVE)
                    .findFirst()
                    .orElse(null);

            if (winningTeamKey != null) {
                List<String> winningPlayers = teamManager.getPlayersInTeam(winningTeamKey);
                String player1Name = getPlayerNameByUUID(UUID.fromString(winningPlayers.get(0)), OneDayTitan.getServerInstance());
                String player2Name = (winningPlayers.size() > 1) ? getPlayerNameByUUID(UUID.fromString(winningPlayers.get(1)), OneDayTitan.getServerInstance()) : "solo";
                String victoryMessage = (winningPlayers.size() > 1) ?
                        OneDayTitan.getPrefix() + "§5" + player1Name + " §band §5" + player2Name + " §bhave won this §5OneDayTitan§b! Congrats!" :
                        OneDayTitan.getPrefix() + "§5" + player1Name +" §bhas won this §5OneDayTitan§b! Congrats!";

                OneDayTitan.getServerInstance().method_3760().method_14571().forEach(p -> {
                    p.method_7353(class_2561.method_30163(victoryMessage), false);
                    p.method_17356(class_3417.field_14702, class_3419.field_15248, 2.0F, 1.0F);
                });
            }
        }
    }
    @Unique
    private String getPlayerNameByUUID(UUID uuid, MinecraftServer server) {
        GameProfile profile = server.method_3793().method_14512(uuid).orElse(null);
        return (profile != null) ? profile.getName() : "Unknown Player";
    }
    @Unique
    private class_3222 getKillerFromDamageTracker(class_3222 player) {
        class_1283 damageTracker = player.method_6066();
        class_1281 recentDamage = damageTracker.method_35041();
        if (recentDamage != null) {
            class_1282 damageSource = recentDamage.method_5499();
            class_1297 attacker = damageSource.method_5529();
            if (attacker instanceof class_3222) {
                return (class_3222) attacker;
            }
            class_3222 killer = null;
            if (attacker != null) {
                killer = getPlayerFromEntity(attacker);
                if (killer != null) {
                    return killer;
                }
            }
            class_1297 sourceEntity = damageSource.method_5526();
            if (sourceEntity != null && sourceEntity != attacker) {
                killer = getPlayerFromEntity(sourceEntity);
                if (killer != null) {
                    return killer;
                }
            }
        } else if(damageTracker.method_5541() != null){
            class_1297 attacker = damageTracker.method_5541();

            if (attacker instanceof class_3222) {
                return (class_3222) attacker;
            }
            class_3222 killer = null;
            if (attacker != null) {
                killer = getPlayerFromEntity(attacker);
                if (killer != null) {
                    return killer;
                }
            }
        }

        return null;
    }
    @Unique
    private class_3222 getKillerFromDamageSource(class_1282 source) {
        class_1297 attacker = source.method_5529();
        class_1297 sourceEntity = source.method_5526();
        if (attacker instanceof class_3222) {
            return (class_3222) attacker;
        }
        class_3222 killer = null;
        if (attacker != null) {
            killer = getPlayerFromEntity(attacker);
            if (killer != null) {
                return killer;
            }
        }
        if (sourceEntity != null && sourceEntity != attacker) {
            killer = getPlayerFromEntity(sourceEntity);
            if (killer != null) {
                return killer;
            }
        }
        return null;
    }

    @Unique
    private class_3222 getPlayerFromEntity(class_1297 entity) {
        if (entity instanceof class_3222) {
            return (class_3222) entity;
        } else if (entity instanceof class_1676) {
            class_1297 owner = ((class_1676) entity).method_24921();
            if (owner instanceof class_3222) {
                return (class_3222) owner;
            }
        } else if (entity instanceof class_1321) {
            class_1297 owner = ((class_1321) entity).method_6177();
            if (owner instanceof class_3222) {
                return (class_3222) owner;
            }
        } else if (entity instanceof class_1295) {
            class_1297 owner = ((class_1295) entity).method_5601();
            if (owner instanceof class_3222) {
                return (class_3222) owner;
            }
        }
        return null;
    }

    @Inject(at = @At("HEAD"), method = "damage(Lnet/minecraft/entity/damage/DamageSource;F)Z", cancellable = true)
    public void damage(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (ConfigHandler.getState(OneDayTitan.getConfigPath()) != GameState.STARTED || StartCommand.protectionTime) {
            cir.setReturnValue(false);
        }
    }

    @Inject(at = @At("HEAD"), method = "attack(Lnet/minecraft/entity/Entity;)V", cancellable = true)
    public void attack(class_1297 target, CallbackInfo ci) {
        if (ConfigHandler.getState(OneDayTitan.getConfigPath()) != GameState.STARTED) {
            if (target instanceof class_3222) {
                class_3222 attackedPlayer = (class_3222) target;
                class_3222 attacker = (class_3222) (Object) this;
                class_1799 heldItem = attacker.method_6047();
                class_1792 legendSwordItem = class_2378.field_11142.method_10223(new class_2960("titanfabric", "legend_sword"));
                UUID inviterUuid = TeamCommand.getInviterForPlayer(attacker.method_5667());
                if (heldItem.method_7909().equals(legendSwordItem)) {
                    if (inviterUuid != null && inviterUuid.equals(attackedPlayer.method_5667())) {
                        executeAcceptCommand(attacker, attackedPlayer);
                    } else {
                        executeInviteCommand(attacker, attackedPlayer);
                    }
                }
            }
            ci.cancel();
        }
    }
    @Unique
    private void executeInviteCommand(class_3222 inviter, class_3222 invitee) {
        String targetName = invitee.method_5477().getString();
        String command = "/tteam invite " + targetName;
        Objects.requireNonNull(inviter.method_5682()).method_3734().method_9249(inviter.method_5671(), command);
    }
    @Unique
    private void executeAcceptCommand(class_3222 invitee, class_3222 inviter) {
        String inviterName = inviter.method_5477().getString();
        String command = "/tteam accept " + inviterName;
        Objects.requireNonNull(invitee.method_5682()).method_3734().method_9249(invitee.method_5671(), command);
    }
}
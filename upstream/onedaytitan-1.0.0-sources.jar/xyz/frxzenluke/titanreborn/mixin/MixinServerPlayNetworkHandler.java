package xyz.frxzenluke.titanreborn.mixin;

import net.minecraft.class_156;
import net.minecraft.class_1934;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_2649;
import net.minecraft.class_2792;
import net.minecraft.class_2797;
import net.minecraft.class_2813;
import net.minecraft.class_2846;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import xyz.frxzenluke.titanreborn.OneDayTitan;
import xyz.frxzenluke.titanreborn.handler.ConfigHandler;
import xyz.frxzenluke.titanreborn.handler.GameState;

@Mixin(class_3244.class)
public abstract class MixinServerPlayNetworkHandler implements class_2792 {

    @Shadow
    private class_3222 player;
    @Final
    @Shadow
    private MinecraftServer server;

    @Inject(method = "onChatMessage", at = @At("HEAD"), cancellable = true)
    public void onChatMessage(class_2797 packet, CallbackInfo ci) {
        if(packet.method_12114().startsWith("/me")) {
            ci.cancel();
            return;
        }
        if(packet.method_12114().startsWith("/")){
            return;
        }
        if(packet.method_12114().contains("nigger") || packet.method_12114().contains("nigge") || packet.method_12114().contains("nigga") || packet.method_12114().contains("negger") || packet.method_12114().contains("negga") || packet.method_12114().contains("niga")) {
            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§cWe do not support racism!"), false);
            ci.cancel();
            return;
        }
        if(player.method_5687(2)) {
            server.method_3760().method_14616(class_2561.method_30163("").method_27662().method_10852(class_2561.method_30163("§cStaff §8| §c" + player.method_5477().method_10851()).method_27662()).method_10852(class_2561.method_30163(" §8» §f").method_27662()).method_27693(packet.method_12114()), class_2556.field_11735, class_156.field_25140);
        } else {
            server.method_3760().method_14616(class_2561.method_30163("").method_27662().method_10852(class_2561.method_30163( "§7" + player.method_5477().method_10851()).method_27662()).method_10852(class_2561.method_30163(" §8» §f").method_27662()).method_27693(packet.method_12114()), class_2556.field_11735, class_156.field_25140);
        }
        ci.cancel();
    }


    @Inject(at = @At("HEAD"), method = "onPlayerAction", cancellable = true)
    public void onPlayerAction(class_2846 packet, CallbackInfo ci) {
        if(ConfigHandler.getState(OneDayTitan.getConfigPath()) == GameState.LOBBY) {
            if ((packet.method_12363() == class_2846.class_2847.field_12975 || packet.method_12363() == class_2846.class_2847.field_12970) || packet.method_12363() == class_2846.class_2847.field_12969) {
                if (player.field_13974.method_14257() != class_1934.field_9220) {
                    ci.cancel();
                    syncInventory();
                }
            }
        }
    }

    @Inject(at = @At("HEAD"), method = "onClickSlot", cancellable = true)
    public void onClickSlot(class_2813 packet, CallbackInfo ci) {
        if(ConfigHandler.getState(OneDayTitan.getConfigPath()) == GameState.LOBBY && player.field_13974.method_14257() != class_1934.field_9220) {
            ci.cancel();
            syncInventory();
        }
    }

    private void syncInventory() {
        class_3222 player = ((class_3244)(Object)this).field_14140;
        player.field_13987.method_14364(new class_2649(
                player.field_7512.field_7763,
                0,
                player.field_7512.method_7602(),
                player.field_7512.method_34255()
        ));
    }
}
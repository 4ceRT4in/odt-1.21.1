package xyz.frxzenluke.titanreborn.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;
import net.minecraft.class_156;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_3324;

@Mixin({class_3324.class})
public class BroadcastChatMessageMixin {
    @Inject(at = {@At("HEAD")}, method = {"broadcast(Lnet/minecraft/text/Text;Lnet/minecraft/network/MessageType;Ljava/util/UUID;)V"}, cancellable = true)
    void filterBroadCastMessages(class_2561 message, class_2556 type, UUID sender, CallbackInfo ci) {
        try {
            if (type != class_2556.field_11735 || sender != class_156.field_25140)
                return;
            String key = ((class_2588)message).method_11022();
            if (!BlockMessage(key))
                return;
            ci.cancel();
        } catch (ClassCastException exception) {
        }
    }

    private boolean BlockMessage(String key) {
        switch (key) {
            case "multiplayer.player.joined":
            case "multiplayer.player.left":
            case "multiplayer.player.joined.renamed":
                return true;
        }
        if(key.contains("death")){
            return true;
        }
        return false;
    }
}


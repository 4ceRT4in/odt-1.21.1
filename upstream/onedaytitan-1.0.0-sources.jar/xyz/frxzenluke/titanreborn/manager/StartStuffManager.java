package xyz.frxzenluke.titanreborn.manager;

import xyz.frxzenluke.titanreborn.OneDayTitan;

import java.io.*;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class StartStuffManager {

    private static final File CONFIG_FILE = new File("config/startStuff.json");

    public static void saveStartStuff(class_3222 player) {
        try {
            class_2487 nbtData = new class_2487();
            class_2499 inventoryList = new class_2499();
            for (class_1799 itemStack : player.method_31548().field_7547) {
                class_2487 itemData = itemStack.method_7953(new class_2487());
                inventoryList.add(itemData);
            }
            class_2499 armorList = new class_2499();
            for (class_1799 armorPiece : player.method_31548().field_7548) {
                class_2487 itemData = armorPiece.method_7953(new class_2487());
                armorList.add(itemData);
            }
            nbtData.method_10566("inventory", inventoryList);
            nbtData.method_10566("armor", armorList);
            FileOutputStream fileOutputStream = new FileOutputStream(CONFIG_FILE);
            class_2507.method_10634(nbtData, fileOutputStream);
            fileOutputStream.close();

            player.method_7353(class_2561.method_30163(OneDayTitan.getPrefix() + "§aStart Equipment successfully saved!"), false);
        } catch (IOException e) {
            player.method_7353(class_2561.method_30163("§cError saving start stuff! -> look console for more details"), false);
            e.printStackTrace();
        }
    }

    public static void loadStartStuff(class_3222 player) {
        try {
            FileInputStream fileInputStream = new FileInputStream(CONFIG_FILE);
            class_2487 nbtData = class_2507.method_10629(fileInputStream);
            fileInputStream.close();

            class_2499 inventoryList = nbtData.method_10554("inventory", 10);
            for (int i = 0; i < inventoryList.size(); i++) {
                class_1799 itemStack = class_1799.method_7915(inventoryList.method_10602(i));
                player.method_31548().method_5447(i, itemStack);
            }

            class_2499 armorList = nbtData.method_10554("armor", 10);
            for (int i = 0; i < armorList.size(); i++) {
                class_1799 armorPiece = class_1799.method_7915(armorList.method_10602(i));
                player.method_31548().field_7548.set(i, armorPiece);
            }
        } catch (IOException e) {
        }
    }
}